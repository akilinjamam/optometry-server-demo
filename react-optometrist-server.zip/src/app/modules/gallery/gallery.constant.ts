export const gallerySearchableField = ["title", "email", "name"];
