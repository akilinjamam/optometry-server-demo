export const publicationSearchableField = ["title"];
