export const eventSearchableField = [
  "title",
  "email",
  "name",
  "eventDate",
  "description",
  "deadline",
];
