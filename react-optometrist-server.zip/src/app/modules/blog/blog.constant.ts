export const blogSearchableField = [
  "title",
  "email",
  "name",
  "release_date",
  "description",
];
