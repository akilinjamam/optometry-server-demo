export const memberSearchableField = [
  "email",
  "name",
  "member_id",
  "designation",
  "address",
  "mobile_no",
];
