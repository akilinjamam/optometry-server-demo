export type ISearchTerm = {
  searchTerm?: string | number;
};
